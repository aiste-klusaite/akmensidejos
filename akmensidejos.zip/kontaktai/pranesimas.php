<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pranešimas</title>
    <link rel="stylesheet" href="../css/pranesimas.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Barlow|Frank+Ruhl+Libre|Taviraj&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="box">
            <div class="zinute"><h3> Ačiū, Jūsų laišką gavome ir netrukus susisieksime!</h3></div>
             <div class="nuoroda"><a href="kontaktai.php">Grįžti į puslapį >></a></div>
        </div>
    </div>
    <script src=""></script>
</body>
</html>
