<?php
 require __DIR__ . '/../forms/contactForm.php';

?>

<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontaktai</title>
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Barlow|Frank+Ruhl+Libre|Taviraj&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/kontaktai.css">
</head>

<body>
    <div class="container">
        <div class="fixed_header">
        <div class="header">
            <div class="logo">
                <div class="name">
                    <h1>AKMENS IDĖJOS</h1>
                    <a class="location" href="https://www.google.lt/maps/place/Til%C5%BE%C4%97s+g.+319,+%C5%A0iauliai+76126/@55.9626062,23.3451112,17z/data=!3m1!4b1!4m5!3m4!1s0x46e5fd2a0181e4d3:0x41104dde58bbbbc7!8m2!3d55.9626062!4d23.3472999"><i class="fas fa-map-marker-alt"></i>Tilžės g. 319, Sutkūnų km., Šiaulių raj.</a>
                    <a class="phone" href="tel:+37063873778"><i class="fas fa-phone-square">
        </i>+37063873778</a>
                    <a class="phone2" href="tel:+37065642802"> +37065642802</a>
                </div>
            </div>
            <div class="nav-bar">
                <div id="burger" class="burger">
                    <div class="line1"></div>
                    <div class="line2"></div>
                    <div class="line3"></div>
                </div>
                <div class="nav-links">
                    <div><a class="nav" href="../index.php">PAGRINDINIS</a></div>
                    <div><a class="nav" href="../apie/apie.php">APIE MUS</a></div>
                    <div><a class="nav" href="../paslaugos/paslaugos.php">PASLAUGOS</a></div>
                    <div><a class="nav" href="../galerija/galerija.php">GALERIJA</a></div>
                    <div><a class="nav" href="kontaktai.php">KONTAKTAI</a></div>
                </div>
                <div class="contact-links">
                <div><span>Klausimai telefonu d.d. 8 - 18 val.:</span></div>
                <div><span>+37063873778;</span></div>
                <div><span>+37065642802;</span></div>
                </div>
            </div>
        </div>
        </div>
        <div class="contact">
            <div class="title"><h3>KONTAKTAI</h3></div>
            <div class="adress_div">
                <div class="info_div">
                    <div class="info">
                    <h4>Kontaktai</h4>
                        <p>El.paštas: <a href="mailto:akmensidejos@inbox.lt"> akmensidejos@inbox.lt</a></p>
                        <p>Telefonas (1): <a href="tel:+37063873778"> 8 638 737 78</a></p>
                        <p>Telefonas (2): <a href="tel:+37065642802"> 8 656 428 02</a></p>
                    <h5>Projektavimo darbai</h5>
                        <p>El.paštas: <a href="mailto:projektai@graniteka.lt"> projektai@graniteka.lt</a></p>
                        <p>Telefonas: <a href="tel:+37069956524"> 8 699 565 24</a></p>
                    <h4>Adresas ir darbo laikas</h4>
                        <p>Būstinė: Gėlių g. 2, Meškių km., Šiaulių raj.</p>
                        <p>Darbo laikas: I - V: 8:00 - 18:00;</p>
                        <p>Aikštelė: Tilžės g. 319, Sutkūnų km., Šiaulių raj.</p>
                        <p>Darbo laikas: I - VI: 10:00 - 16:00;</p>
                    <h4>Įmonės rekvizitai</h4>
                        <p>UAB Akmens Idėjos</p>
                        <p>im.k.: 301742114</p>
                        <p>PVM LT100011579312</p>
                    <h4>Įmonių partnerių kontaktai</h4>
                       <div class="links"><a href="https://www.facebook.com/gardenija.lt"><i class="fab fa-facebook i-mark"></i> UAB "Gardenija - Jolantos gėlės"</a>
                        <a href="https://www.info.lt/imones/Sodink-ir-augink-UAB/2378509"><i class="fas fa-map-marker-alt i-map"></i> UAB "Sodink ir augink"</a>
                        </div>
                    </div>        
                </div>
                <div class="contact_form">
                    <h4>Parašykite mums</h4>
                    <form method="post" action="kontaktai.php">
                        <label>VARDAS</label>
                        <input  class="input" type="text" name="firstName" required>
                         <label>EL. PAŠTAS</label>
                        <input class="input" type="email" name="email" required>
                         <label>TELEFONAS</label>
                        <input class="input" type="tel" name="phone" required>
                        <label>ŽINUTĖ</label>
                        <textarea name="subject"></textarea>
                        <input class="button" name="submit" type="submit" value="Siųsti" required>
                    </form>
                </div>
            </div>
            <div class="map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2233.2363763812887!2d23.34511121585579!3d55.962606180610045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46e5fd2a0181e4d3%3A0x41104dde58bbbbc7!2zVGlsxb7El3MgZy4gMzE5LCDFoGlhdWxpYWkgNzYxMjY!5e0!3m2!1slt!2slt!4v1591082857204!5m2!1slt!2slt" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></div> 
        </div>
    <div class="footer">
        <div class="rekvizitai">
            <h4>REKVIZITAI</h4>
            <p>UAB Akmens Idėjos</p>
            <p>im.k.: 301742114</p>
            <p>PVM LT100011579312</p>
        </div>
        <div class="adresas">
            <h4>ADRESAS</h4>
            <p>Būstinė: Gėlių g. 2, Meškių km., Šiaulių raj.</p>
            <p>Darbo laikas: I - V: 8:00 - 18:00;</p>
            <p>Aikštelė: Tilžės g. 319, Sutkūnų km., Šiaulių raj.</p>
            <p>Darbo laikas: I - VI: 10:00 - 16:00;</p>
            
        </div>
        <div class="contact_info">
        <h4>KONTAKTAI</h4>
        <a class="tel" href="tel:+37063873778"><i class="fas fa-phone-square"></i>  8 638 737 78</a>
        <a class="tel" href="tel:+37065642802"><i class="fas fa-phone-square"></i>  8 656 428 02</a>
         <a class="tel" href="mailto:akmensidejos@inbox.lt"><i class="fas fa-envelope-square"></i>  akmensidejos@inbox.lt</a>
        <div class="contact_info2"> 
        <p>Projektavimo darbai:</p> 
        <a  class="tel" href="tel:+37069956524"><i class="fas fa-phone-square">
        </i>  8 699 565 24</a>
        <a class="tel" href="mailto:projektai@graniteka.lt"><i class="fas fa-envelope-square"></i>  projektai@graniteka.lt</a>
        </div>
        </div>
        </div>
        <div class="privacy"><p>Visos teisės saugomas &copy; <?php echo date('Y'); ?> UAB "AKMENS IDĖJOS"</p>
    </div>
    <div class="cookie-banner">
        <p>Jūsų patogumui, šioje svetainėje naudojami slapukai, kurie užtikrina sklandų naršymą tinklapyje. </p>
        <button class="cookie-button">Sutinku</button>
    </div>
</div>
    <script src="../js/header.js"></script>
    <script src="../js/cookie.js"></script>
</body>
</html>
