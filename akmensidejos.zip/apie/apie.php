<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apie mus</title>
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Barlow|Frank+Ruhl+Libre|Taviraj&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/apie.css">
</head>
<body>
    <div class="container">
        <div class="fixed_header">
        <div class="header">
            <div class="logo">
                <div class="name">
                    <h1>AKMENS IDĖJOS</h1>
                    <a class="location" href="https://www.google.lt/maps/place/Til%C5%BE%C4%97s+g.+319,+%C5%A0iauliai+76126/@55.9626062,23.3451112,17z/data=!3m1!4b1!4m5!3m4!1s0x46e5fd2a0181e4d3:0x41104dde58bbbbc7!8m2!3d55.9626062!4d23.3472999"><i class="fas fa-map-marker-alt"></i>Tilžės g. 319, Sutkūnų km., Šiaulių raj.</a>
                    <a class="phone" href="tel:+37063873778"><i class="fas fa-phone-square">
        </i>+37063873778</a>
                    <a class="phone2" href="tel:+37065642802"> +37065642802</a>
                </div>
            </div>
            <div class="nav-bar">
                <div id="burger" class="burger">
                    <div class="line1"></div>
                    <div class="line2"></div>
                    <div class="line3"></div>
                </div>
                <div class="nav-links">
                    <div><a class="nav" href="../index.php">PAGRINDINIS</a></div>
                    <div><a class="nav" href="apie.php">APIE MUS</a></div>
                    <div><a class="nav" href="../paslaugos/paslaugos.php">PASLAUGOS</a></div>
                    <div><a class="nav" href="../galerija/galerija.php">GALERIJA</a></div>
                    <div><a class="nav" href="../kontaktai/kontaktai.php">KONTAKTAI</a></div>
                </div>
                <div class="contact-links">
                <div><span>Klausimai telefonu d.d. 8 - 18 val.:</span></div>
                <div><span>+37063873778;</span></div>
                <div><span>+37065642802;</span></div>
                </div>
            </div>
        </div>
        </div>
        <div class="about">
            <div class="title"><h3>APIE MUSŲ ĮMONĘ</h3></div>
               <div class="content">
                   <div class="text">
                <div class="paragraph"><p> AB "Akmens idėjos" savo veiklą pradėjo 2008 metais. Per 12 metų buvo įvykdyta daug projektų,  kurie pateisino mūsų  klientų lūkesčius.</p>
                 <p>„Akmens idėjų“ <a class="direction" href="../paslaugos/paslaugos.php">paslaugų spektras</a> labai platus, apimantis visus būtiniausius darbus, skirtus kapaviečių tvarkymui: nuo paminklų projektavimo iki trinkelių klojimo.</p>
               <p> Klientams yra siūlomi ne tik standartiniai pagamintų paminklų variantai. Galima atlikti  ir individualius  paminklų projektus.</p> 
                <p>Siūlome dar vieną, šiuo metu labai aktualią paslaugą –   neturintiems  galimybių  pasirūpinti artimųjų kapais padėsime juos sutvarkyti arba renovuoti. Įprastai darbus atliekame Šiaulių apskrityje, bet pagal dvišalį susitarimą galime atvykti ir į kitus Lietuvos regionus.</p>
                <p>„Akmens idėjoms“ labai  svarbi teikiamų paslaugų kokybė, todėl paminklams, skaldai bei plokštėms naudojamas   granitas   iš Suomijos, Švedijos, Indijos, Lenkijos bei Kinijos.</p>
                <p>„Akmens idėjų“ komanda klientus konsultuoja, kaip išsirinkti optimaliausią paminklo, kapavietės sutvarkymo, augalų pasirinkimo variantą.</p>
                <p>„Akmens idėjos“ garantuoja kokybę bei gaminių ilgaamžiskumą!</p></div> 
                   <div class="regards"><p>UAB "AKMENS IDĖJOS"</p></div></div>
                <div class="image"><img src="../images/paminklai/foto18.jpg" width="100%"></div>
            </div>
        </div>
    <div class="footer">
        <div class="rekvizitai">
            <h4>REKVIZITAI</h4>
            <p>UAB Akmens Idėjos</p>
            <p>im.k.: 301742114</p>
            <p>PVM LT100011579312</p>
        </div>
        <div class="adresas">
            <h4>ADRESAS</h4>
            <p>Būstinė: Gėlių g. 2, Meškių km., Šiaulių raj.</p>
            <p>Darbo laikas: I - V: 8:00 - 18:00;</p>
            <p>Aikštelė: Tilžės g. 319, Sutkūnų km., Šiaulių raj.</p>
            <p>Darbo laikas: I - VI: 10:00 - 16:00;</p>
            <p></p>
        </div>
        <div class="contact_info">
        <h4>KONTAKTAI</h4>
        <a class="tel" href="tel:+37063873778"><i class="fas fa-phone-square"></i>  8 638 737 78</a>
        <a class="tel" href="tel:+37065642802"><i class="fas fa-phone-square"></i>  8 656 428 02</a>
         <a class="tel" href="mailto:akmensidejos@inbox.lt"><i class="fas fa-envelope-square"></i>  akmensidejos@inbox.lt</a>
        <div class="contact_info2"> 
        <p>Projektavimo darbai:</p> 
        <a  class="tel" href="tel:+37069956524"><i class="fas fa-phone-square">
        </i>  8 699 565 24</a>
        <a class="tel" href="mailto:projektai@graniteka.lt"><i class="fas fa-envelope-square"></i>  projektai@graniteka.lt</a>
        </div>
        </div>
        </div>
        <div class="privacy"><p>Visos teisės saugomas &copy; <?php echo date('Y'); ?> UAB "AKMENS IDĖJOS"</p>
    </div>
    <div class="cookie-banner">
        <p>Jūsų patogumui, šioje svetainėje naudojami slapukai, kurie užtikrina sklandų naršymą tinklapyje. </p>
        <button class="cookie-button">SUTINKU</button>
    </div>
</div>
    <script src="../js/header.js"></script>
    <script src="../js/cookie.js"></script>
</body>
</html>


