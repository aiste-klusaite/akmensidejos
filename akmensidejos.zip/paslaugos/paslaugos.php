<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paslaugos</title>
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Barlow|Frank+Ruhl+Libre|Taviraj&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/paslaugos.css">
</head>

<body>
    <div class="container">
        <div class="fixed_header">
        <div class="header">
            <div class="logo">
                <div class="name">
                    <h1>AKMENS IDĖJOS</h1>
                    <a class="location" href="https://www.google.lt/maps/place/Til%C5%BE%C4%97s+g.+319,+%C5%A0iauliai+76126/@55.9626062,23.3451112,17z/data=!3m1!4b1!4m5!3m4!1s0x46e5fd2a0181e4d3:0x41104dde58bbbbc7!8m2!3d55.9626062!4d23.3472999"><i class="fas fa-map-marker-alt"></i>Tilžės g. 319, Sutkūnų km., Šiaulių raj.</a>
                    <a class="phone" href="tel:+37063873778"><i class="fas fa-phone-square">
        </i>+37063873778</a>
                    <a class="phone2" href="tel:+37065642802"> +37065642802</a>
                </div>
            </div>
            <div class="nav-bar">
                <div id="burger" class="burger">
                    <div class="line1"></div>
                    <div class="line2"></div>
                    <div class="line3"></div>
                </div>
                <div class="nav-links">
                    <div><a class="nav" href="../index.php">PAGRINDINIS</a></div>
                    <div><a class="nav" href="../apie/apie.php">APIE MUS</a></div>
                    <div><a class="nav" href="paslaugos.php">PASLAUGOS</a></div>
                    <div><a class="nav" href="../galerija/galerija.php">GALERIJA</a></div>
                    <div><a class="nav" href="../kontaktai/kontaktai.php">KONTAKTAI</a></div>
                </div>
                <div class="contact-links">
                <div><span>Klausimai telefonu d.d. 8 - 18 val.:</span></div>
                <div><span>+37063873778;</span></div>
                <div><span>+37065642802;</span></div>
                </div>
            </div>
        </div>
        </div>
        <div class="paslaugos">
            <div class="title"><h3>PASLAUGOS</h3></div>
            <div class="paslaugos_list">
                <div class="list1">
                    <ul>
                        <li>Paminklų ir antkapių gamyba</li>
                        <p>Pagal <span class="list_span">individualų projektą</span> gaminame kliento lūkesčius atitinkantį paminklą. Konsultuojame, kaip išsirinkti paminklinio akmens spalvą, kaip derinti kitas kapavietės detales. Prekiaujame jau <span class="list_span">pagamintais paminklais</span>.</p>
                        <li>Kapavietės projektavimas ir įrengimas</li>
                        <p>Gaminame ne tik paminklus pagal individualų užsakymą, bet kuriame bendrą kapavietės vaizdą. Pagal kliento pageidavimus pateikiame <span class="list_span">kapavietės projektą</span>, kuriame  unikalų kapavietės  dizainą. </p>
                        <li>Kapavietės želdinių projektavimas ir apsodinimas</li>
                        <p>Kuriame kapo tvarkymo projektą ir konsultuojame,  išsirenkant tinkamiausias <span class="list_span">gėles (spigės, jurginai, begonijos arba ledinukai) bei želdinius</span> ir puošybos elementus, derančius kapavietėje. Bendradarbiaudami su <a class="fb_link" href="https://www.facebook.com/gardenija.lt">"Gardenija - Jolantos gėlės"</a> bei <a class="info_link" href="https://www.info.lt/imones/Sodink-ir-augink-UAB/2378509">"Sodink ir augink"</a> užtikriname augalų kokybę.</p>
                        <li>Kapavietės renovacija ir restauracija</li>
                        <p>Senos kapavietės reikalauja atnaujinimo dėl per ilgą laiką nusidėvėjusio paminklinio akmens, sutrūkinėjusių pamatų ar plytelių, ilgalaikės kapo  nepriežiūros. Siūlome <span class="list_span">kapavietės restauravimo/renovacijos</span> paslaugą. Ivertinus kapavietės buklę, atliekami restauravimo arba renovacijos darbai.</p>
                    </ul>
                </div>
                <div class="image"><img src="../images/geles/gele2.jpg" width="100%"></div>
            </div>
            <div class="paslaugos_list">
                <div class="image"><img src="../images/paminklai/foto14.JPG" width="100%"></div>
                <div class="list2">
                     <ul>
                        <li>Plokščių, trinkelių, plytelių klojimas, skalda</li>
                         <p><span class="list_span">Granito plokštės</span> - puikus pasirinkimas ir paprastas būdas, norint, kad kapavietė atrodytų tvarkinga, estetiška. Plokštės yra ilgaamžės, o granito akmuo, laikui bėgant, nepakeičia savo spalvos.<br/>
                        Dar vienas puikus būdas papuošti kapavietę -<span class="list_span"> granito akmens skalda</span>, kuri tinka visiems metų laikams bei kontroliuoja piktžolių augimą. Galime pasiūlyti įvairių spalvų skaldą bei sukurti originalų kapavietės vaizdą.<br/>
                        Klientams, norintiems išlaikyti kapavietės estetiką, siūlome <span class="list_span">trinkelių bei plytelių klojimo</span> paslaugą.</p>
                        <li>Betonavimo darbai</li>
                         <p>Renovuojant kapavietę, klojant granito plokštes ar keičiant seną paminklą, reikalingi nauji pamatai. Liejame<span class="list_span"> betono pamatus.</span></p>
                        <li>Kapavietės tvarkymas ir priežiūra</li>
                         <p>Labai reikalinga paslauga klietams, neturintiems galimybių pasirūpinti artimųjų kapais. Teikiame vienkartinę tvarkymo paslaugą, atliekame<span class="list_span"> nuolatinę kapų priežiūrą</span> visą sezoną pagal abipusį susitarimą.</p>
                        <li>Kapavietės aksesuarai</li>
                         <p><span class="list_span">Suolai.</span> Atsižvelgdami į kliento pageidavimą, pagal individualų užsakymą gaminame suolus iš akmens. Taip pat siūlome kompaktiškų, turinčių atsilenkimo mechanizmą, suolų. Sėdimoji dalis pagaminta iš plastiko, kojos – metalinės. <br/>
                         <span class="list_span">Vazos.</span> Siūlome tekintas, kiniečių gamybos arba mūsų meistrų sukurtas granito akmens, iš kurio pagamintas paminklas ar plokštės, vazas, kurios estetiškai papildo bendrą kapavietės vaizdą.</p>
                    </ul>
                </div>
            </div>
        </div>
    <div class="footer">
        <div class="rekvizitai">
            <h4>REKVIZITAI</h4>
            <p>UAB Akmens Idėjos</p>
            <p>im.k.: 301742114</p>
            <p>PVM LT100011579312</p>
        </div>
        <div class="adresas">
            <h4>ADRESAS</h4>
            <p>Būstinė: Gėlių g. 2, Meškių km., Šiaulių raj.</p>
            <p>Darbo laikas: I - V: 8:00 - 18:00;</p>
            <p>Aikštelė: Tilžės g. 319, Sutkūnų km., Šiaulių raj.</p>
            <p>Darbo laikas: I - VI: 10:00 - 16:00;</p>
            <p></p>
        </div>
        <div class="contact_info">
        <h4>KONTAKTAI</h4>
        <a class="tel" href="tel:+37063873778"><i class="fas fa-phone-square"></i>  8 638 737 78</a>
        <a class="tel" href="tel:+37065642802"><i class="fas fa-phone-square"></i>  8 656 428 02</a>
         <a class="tel" href="mailto:akmensidejos@inbox.lt"><i class="fas fa-envelope-square"></i>  akmensidejos@inbox.lt</a>
        <div class="contact_info2"> 
        <p>Projektavimo darbai:</p> 
        <a  class="tel" href="tel:+37069956524"><i class="fas fa-phone-square">
        </i>  8 699 565 24</a>
        <a class="tel" href="mailto:projektai@graniteka.lt"><i class="fas fa-envelope-square"></i>  projektai@graniteka.lt</a>
        </div>
        </div>
        </div>
        <div class="privacy"><p>Visos teisės saugomas &copy; <?php echo date('Y'); ?> UAB "AKMENS IDĖJOS"</p>
    </div>
    <div class="cookie-banner">
        <p>Jūsų patogumui, šioje svetainėje naudojami slapukai, kurie užtikrina sklandų naršymą tinklapyje. </p>
        <button class="cookie-button">Sutinku</button>
    </div>
</div>
    <script src="../js/header.js"></script>
    <script src="../js/cookie.js"></script>
</body>
</html>
