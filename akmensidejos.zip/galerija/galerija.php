<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galerija</title>
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Barlow|Frank+Ruhl+Libre|Taviraj&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/galerija.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
</head>

<body>
    <div class="container">
        <div class="fixed_header">
        <div class="header">
            <div class="logo">
                <div class="name">
                    <h1>AKMENS IDĖJOS</h1>
                    <a class="location" href="https://www.google.lt/maps/place/Til%C5%BE%C4%97s+g.+319,+%C5%A0iauliai+76126/@55.9626062,23.3451112,17z/data=!3m1!4b1!4m5!3m4!1s0x46e5fd2a0181e4d3:0x41104dde58bbbbc7!8m2!3d55.9626062!4d23.3472999"><i class="fas fa-map-marker-alt"></i>Tilžės g. 319, Sutkūnų km., Šiaulių raj.</a>
                    <a class="phone" href="tel:+37063873778"><i class="fas fa-phone-square">
        </i>+37063873778</a>
                    <a class="phone2" href="tel:+37065642802"> +37065642802</a>
                </div>
            </div>
            <div class="nav-bar">
                <div id="burger" class="burger">
                    <div class="line1"></div>
                    <div class="line2"></div>
                    <div class="line3"></div>
                </div>
                <div class="nav-links">
                    <div><a class="nav" href="../index.php">PAGRINDINIS</a></div>
                    <div><a class="nav" href="../apie/apie.php">APIE MUS</a></div>
                    <div><a class="nav" href="../paslaugos/paslaugos.php">PASLAUGOS</a></div>
                    <div><a class="nav" href="galerija.php">GALERIJA</a></div>
                    <div><a class="nav" href="../kontaktai/kontaktai.php">KONTAKTAI</a></div>
                </div>
                <div class="contact-links">
                <div><span>Klausimai telefonu d.d. 8 - 18 val.:</span></div>
                <div><span>+37063873778;</span></div>
                <div><span>+37065642802;</span></div>
                </div>
            </div>
        </div>
        </div>
        <div class="galerija">
            <div class="title"><h3>DARBŲ GALERIJA</h3></div>
            <div class="foto_row">
                <div class="pic"><a href="../images/paminklai/foto4.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto4.jpg" width="100%" ></a></div>
                <div class="pic"><a href="../images/paminklai/foto5.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto5.JPG" width="100%" ></a></div>
                <div class="pic"><a href="../images/paminklai/foto12.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto12.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto13.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto13.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto14.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto14.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto15.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto15.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto18.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto18.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto21.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto21.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto22.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto22.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto23.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto23.jpg" width="110%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto25.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto25.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto26.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto26.jpg" width="110%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto27.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto27.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto29.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto29.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto31.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto31.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto32.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto32.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto35.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto35.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto37.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto37.jpg" width="110%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto38.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto38.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto40.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto40.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto41.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto41.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto46.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto46.jpg" width="110%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto47.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto47.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto42.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto42.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto45.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto45.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto50.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto50.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto17.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto17.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto19.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto19.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto9.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto9.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/paminklai/foto11.jpg" data-fancybox="gallery"><img src="../images/paminklai/foto11.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/restauracija/restauracija1.jpg" data-fancybox="gallery"><img src="../images/restauracija/restauracija1.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/restauracija/restauracija2.jpg" data-fancybox="gallery"><img src="../images/restauracija/restauracija2.jpg" width="100%"></a></div>
                <div class="pic"><a href="../images/restauracija/restauracija3.jpg" data-fancybox="gallery"><img src="../images/restauracija/restauracija3.jpg" width="100%"></a></div>
            </div>
        </div>
    <div class="footer">
        <div class="rekvizitai">
            <h4>REKVIZITAI</h4>
            <p>UAB Akmens Idėjos</p>
            <p>im.k.: 301742114</p>
            <p>PVM LT100011579312</p>
        </div>
        <div class="adresas">
            <h4>ADRESAS</h4>
            <p>Būstinė: Gėlių g. 2, Meškių km., Šiaulių raj.</p>
            <p>Darbo laikas: I - V: 8:00 - 18:00;</p>
            <p>Aikštelė: Tilžės g. 319, Sutkūnų km., Šiaulių raj.</p>
            <p>Darbo laikas: I - VI: 10:00 - 16:00;</p>
            <p></p>
        </div>
        <div class="contact_info">
        <h4>KONTAKTAI</h4>
        <a class="tel" href="tel:+37063873778"><i class="fas fa-phone-square"></i>  8 638 737 78</a>
        <a class="tel" href="tel:+37065642802"><i class="fas fa-phone-square"></i>  8 656 428 02</a>
         <a class="tel" href="mailto:akmensidejos@inbox.lt"><i class="fas fa-envelope-square"></i>  akmensidejos@inbox.lt</a>
        <div class="contact_info2"> 
        <p>Projektavimo darbai:</p> 
        <a  class="tel" href="tel:+37069956524"><i class="fas fa-phone-square">
        </i>  8 699 565 24</a>
        <a class="tel" href="mailto:projektai@graniteka.lt"><i class="fas fa-envelope-square"></i>  projektai@graniteka.lt</a>
        </div>
        </div>
        </div>
        <div class="privacy"><p>Visos teisės saugomas &copy; <?php echo date('Y'); ?> UAB "AKMENS IDĖJOS"</p>
    </div>
    <div class="cookie-banner">
        <p>Jūsų patogumui, šioje svetainėje naudojami slapukai, kurie užtikrina sklandų naršymą tinklapyje. </p>
        <button class="cookie-button">Sutinku</button>
    </div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="../js/header.js"></script>
    <script src="../js/cookie.js"></script>
</body>
</html>


