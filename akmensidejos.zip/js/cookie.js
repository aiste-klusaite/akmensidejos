const cookiesBanner = document.querySelector(".cookie-banner");

const cookieBtn = document.querySelector(".cookie-button");

cookieBtn.addEventListener("click", () => {
    cookiesBanner.classList.remove("active");
    localStorage.setItem("cookiesBanner","true")
})
 setTimeout(() => {
     if(!localStorage.getItem("cookiesBanner"))
     cookiesBanner.classList.add("active");
 }, 2000);
             