let slideIndex = 1;
let i;
let mySlides = document.getElementsByClassName("slides");

showSlides(slideIndex);

function plusSlide(n){
    showSlides(slideIndex += n);
}

function currentSlide(n){ 
    showSlides(slideIndex = n);
}

function showSlides (n){
    if( n > mySlides.length){
        slideIndex = 1
    }
    if( n < 1){
        slideIndex = mySlides.length
    }
    for( i = 0; i < mySlides.length; i++){
        mySlides[i].style.display = "none";
    }
    mySlides[slideIndex-1].style.display = "block";

}