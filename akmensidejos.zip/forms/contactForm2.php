<?php 

$vardas = trim($_POST['firstName']);
$email = trim($_POST['email']);
$tel = trim($_POST['phone']);
$msn = trim($_POST['subject']);

if(isset($_POST['submit'])){
    if(!empty($vardas) && !empty($email) && !empty($tel) && !empty($msn)){
      if(filter_var($email, FILTER_VALIDATE_EMAIL)){
          $headers = 'From:' . $email;
          $to = " ";
          $subject = 'Klientas' . $vardas;
          $siuntejas = $tel;
          $message = htmlspecialchars($msn);
          mail($to, $subject, $message, $siuntejas, $headers);
          header("Location: index.php");
          echo "<script>alert('Ačiū, Jūsų laišką gavome ir netrukus susisieksime!')</script>";
      }
  }

    include('database.php');
}
    
?>