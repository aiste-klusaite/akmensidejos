<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "graniteka";

$mysqli = new mysqli($servername, $username, $password, $dbname);
if($mysqli->connect_error){
    echo "Atiprašau, bet kažur įsivėlė klaida.\n";
    echo "Klaida:  $mysqli->connect_error \n";
    exit();
}


$stmt = $mysqli->prepare("INSERT INTO graniteka (vardas, email, tel, zinute) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $_POST['firstName'], $_POST['email'], $_POST['phone'], $_POST['subject']);
$stmt->execute();



?>